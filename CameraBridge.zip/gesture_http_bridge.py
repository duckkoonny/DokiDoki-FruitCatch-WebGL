"""Serve only the latest MediaPipe gesture packet to the Doki Doki web game."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from time import monotonic

ALLOWED_ORIGINS = {"https://duckkoonny.github.io"}


class GestureHttpBridge:
    def __init__(self):
        self.packet = (0.0, b"{}")
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def respond(self, preflight=False):
                origin = self.headers.get("Origin")
                if origin not in ALLOWED_ORIGINS or self.path != "/gestures":
                    self.send_error(403)
                    return
                updated, packet = bridge.packet
                body = packet if monotonic() - updated < 0.35 else b"{}"
                self.send_response(204 if preflight else 200)
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
                self.send_header("Cache-Control", "no-store")
                if preflight:
                    self.send_header("Access-Control-Allow-Methods", "GET")
                    if self.headers.get("Access-Control-Request-Private-Network") == "true":
                        self.send_header("Access-Control-Allow-Private-Network", "true")
                else:
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                if not preflight:
                    self.wfile.write(body)

            def do_GET(self):
                self.respond()

            def do_OPTIONS(self):
                self.respond(preflight=True)

            def setup(self):
                self.request.settimeout(1)
                super().setup()

        self.server = HTTPServer(("127.0.0.1", 8765), Handler)
        self.thread = Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def publish(self, packet):
        self.packet = (monotonic(), packet)

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()

