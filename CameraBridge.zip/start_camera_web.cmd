@echo off
setlocal
pushd "%~dp0"
if not exist ".venv-hand-control\Scripts\python.exe" (
  echo Run install_hand_control.cmd first.
  popd
  pause
  exit /b 1
)
".venv-hand-control\Scripts\python.exe" "unity_hand_control.py" --web
popd
pause
