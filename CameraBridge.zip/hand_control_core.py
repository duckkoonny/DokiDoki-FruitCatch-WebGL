"""Gesture rules, filtering and UDP protocol; no camera/MediaPipe dependency."""
import json
import math
import uuid

NEUTRAL = {"OPEN", "UNKNOWN", "NONE"}


def distance(a, b):
    return math.sqrt(sum((u - v) ** 2 for u, v in zip(a, b)))


def angle(a, b, c):
    u = [x - y for x, y in zip(a, b)]
    v = [x - y for x, y in zip(c, b)]
    denom = math.sqrt(sum(x*x for x in u) * sum(x*x for x in v))
    if denom < 1e-9:
        return 0.0
    cosine = max(-1.0, min(1.0, sum(x*y for x, y in zip(u, v)) / denom))
    return math.degrees(math.acos(cosine))


def classify_hand(landmarks, aspect=4/3, ok_ratio=0.38):
    """Heuristic for palms facing camera. Returns OK/V/FIST/OPEN/UNKNOWN.

    x is scaled to image aspect so distances use the same unit as y.
    World landmarks may instead be passed with aspect=1.
    """
    if len(landmarks) != 21:
        return "UNKNOWN"
    p = [(lm.x * aspect, lm.y, lm.z * aspect) for lm in landmarks]
    if not all(math.isfinite(v) for point in p for v in point):
        return "UNKNOWN"
    palm = distance(p[5], p[17])
    if palm < 1e-5:
        return "UNKNOWN"
    extended, mostly_extended, curled = [], [], []
    for base in (5, 9, 13, 17):
        tip, pip, dip = p[base+3], p[base+1], p[base+2]
        pip_angle = angle(p[base], pip, dip)
        dip_angle = angle(pip, dip, tip)
        extended.append(pip_angle > 150 and dip_angle > 145 and
                        distance(p[0], tip) > distance(p[0], pip) * 1.08)
        mostly_extended.append(pip_angle > 140 and dip_angle > 130 and
                               distance(p[0], tip) > distance(p[0], pip) * 1.04)
        curled.append(pip_angle < 135 or
                      distance(p[0], tip) < distance(p[0], pip) * 1.02)
    # Compare the pinch in the image plane. Estimated fingertip depth is noisy.
    pinch = distance(p[4][:2], p[8][:2])
    if pinch < palm * ok_ratio and sum(mostly_extended[1:]) >= 2:
        return "OK"
    if extended[0] and extended[1] and curled[2] and curled[3]:
        return "V"
    thumb_near_palm = min(distance(p[4], p[5]), distance(p[4], p[9])) < palm
    if all(curled) and thumb_near_palm:
        return "FIST"
    if all(extended):
        return "OPEN"
    return "UNKNOWN"


class HandState:
    def __init__(self, stable_seconds=0.12, rearm_seconds=0.25):
        self.stable_seconds = stable_seconds
        self.rearm_seconds = rearm_seconds
        self.gesture = "NONE"
        self.candidate = "NONE"
        self.candidate_since = 0.0
        self.ok_armed = True
        self.jump_armed = True
        self.dash_count = 0
        self.jump_count = 0

    def update(self, raw, now):
        # Open/unknown/missing hands release movement immediately. Missing hands
        # do not rearm OK, so brief tracking loss cannot repeatedly fire a dash.
        if raw != self.candidate:
            self.candidate = raw
            self.candidate_since = now
        if raw in NEUTRAL:
            self.gesture = raw
        elif now - self.candidate_since >= self.stable_seconds:
            self.gesture = raw
        else:
            self.gesture = "UNKNOWN"
        if now - self.candidate_since >= self.rearm_seconds:
            if raw in ("OPEN", "FIST", "V"):
                self.ok_armed = True
            if raw in ("OPEN", "FIST", "OK"):
                self.jump_armed = True
        if self.gesture == "OK" and self.ok_armed:
            self.dash_count += 1
            self.ok_armed = False
        if self.gesture == "V" and self.jump_armed:
            self.jump_count += 1
            self.jump_armed = False
        return self.gesture


class GestureController:
    def __init__(self, stable_seconds=0.12, rearm_seconds=0.25):
        self.left = HandState(stable_seconds, rearm_seconds)
        self.right = HandState(stable_seconds, rearm_seconds)
        self.session = uuid.uuid4().hex
        self.sequence = 0

    def update(self, left, right, now):
        self.left.update(left, now)
        self.right.update(right, now)

    @property
    def move(self):
        return int(self.right.gesture == "FIST") - int(self.left.gesture == "FIST")

    def packet(self, camera_live=True):
        self.sequence += 1
        return {"version": 1, "session": self.session, "seq": self.sequence,
                "leftFist": int(self.left.gesture == "FIST"),
                "rightFist": int(self.right.gesture == "FIST"),
                "leftDash": self.left.dash_count, "rightDash": self.right.dash_count,
                "jump": self.left.jump_count + self.right.jump_count,
                "leftGesture": self.left.gesture, "rightGesture": self.right.gesture,
                "cameraState": 2 if camera_live else 1}

    def encode(self, camera_live=True, landmarks=None):
        packet = self.packet(camera_live)
        if camera_live and landmarks:
            packet.update(landmarks)
        return json.dumps(packet, separators=(",", ":")).encode("ascii")
