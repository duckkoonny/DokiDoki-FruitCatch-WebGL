@echo off
setlocal
pushd "%~dp0"
if exist ".venv-hand-control\Scripts\python.exe" goto install
set "HAND_PY=%LocalAppData%\Programs\Python\Python312\python.exe"
if exist "%HAND_PY%" (
  "%HAND_PY%" -m venv ".venv-hand-control"
) else (
  py -3.12 -m venv ".venv-hand-control"
)
if errorlevel 1 goto fail
:install
".venv-hand-control\Scripts\python.exe" -m pip install -r "requirements-hand-control.txt" --disable-pip-version-check
if errorlevel 1 goto fail
".venv-hand-control\Scripts\python.exe" "download_model.py"
if errorlevel 1 goto fail
echo Installation complete. Run start_camera_web.cmd.
popd
pause
exit /b 0
:fail
echo Installation failed. Python 3.12 and internet access are required. See messages above.
popd
pause
exit /b 1


