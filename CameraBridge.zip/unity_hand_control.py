"""ESP32-CAM MJPEG -> MediaPipe -> local Unity UDP controls.

The original test.py and camera firmware are intentionally left intact.
"""
import argparse
import json
import socket
import threading
import time
from pathlib import Path

from hand_control_core import GestureController, classify_hand

ROOT = Path(__file__).resolve().parent
CONNECTIONS = [(0,1),(1,2),(2,3),(3,4),(0,5),(5,6),(6,7),(7,8),
               (5,9),(9,10),(10,11),(11,12),(9,13),(13,14),(14,15),
               (15,16),(13,17),(17,18),(18,19),(19,20),(0,17)]


class ESP32Camera:
    def __init__(self, url, cv2):
        self.url, self.cv2 = url, cv2
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.frame = None
        self.frame_id = 0
        self.received_at = 0.0
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def run(self):
        cv2 = self.cv2
        while not self.stop_event.is_set():
            cap = None
            try:
                print("Connecting to ESP32-CAM:", self.url)
                cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG, [
                    cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000,
                    cv2.CAP_PROP_READ_TIMEOUT_MSEC, 3000])
                if not cap.isOpened():
                    raise RuntimeError("Cannot open camera stream")
                while not self.stop_event.is_set():
                    ok, frame = cap.read()
                    if not ok:
                        raise RuntimeError("Camera stream interrupted")
                    with self.lock:
                        self.frame = frame
                        self.frame_id += 1
                        self.received_at = time.monotonic()
            except Exception as exc:
                print("Camera:", exc)
            finally:
                if cap is not None:
                    cap.release()
                with self.lock:
                    self.frame = None
                    self.received_at = 0.0
            self.stop_event.wait(1.0)

    def read(self):
        with self.lock:
            return (None if self.frame is None else self.frame.copy(),
                    self.frame_id, self.received_at)

    def stop(self):
        self.stop_event.set()
        self.thread.join(timeout=6)


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "hand_control_config.json")
    parser.add_argument("--url", help="Override ESP32-CAM stream URL")
    parser.add_argument("--swap-hands", action="store_true", help="Toggle configured handedness")
    parser.add_argument("--no-preview", action="store_true")
    parser.add_argument("--web", action="store_true", help="Enable the local browser connection")
    return parser.parse_args()


def main():
    args = arguments()
    config = json.loads(args.config.read_text(encoding="utf-8-sig"))
    try:
        import cv2
        import mediapipe as mp
        import numpy as np
    except ImportError as exc:
        raise SystemExit("Missing Python packages. Run install_hand_control.cmd first. " + str(exc))
    url = args.url
    if args.web and not url:
        url = input(f"ESP32-CAM stream URL [{config['stream_url']}]: ").strip()
    url = url or config["stream_url"]
    model = Path(config.get("model_path", "hand_landmarker.task"))
    if not model.is_absolute():
        model = args.config.resolve().parent / model
    if not model.is_file():
        raise SystemExit("Model not found: " + str(model))
    port = int(config.get("udp_port", 5055))
    if not 1024 <= port <= 65535:
        raise SystemExit("udp_port must be between 1024 and 65535")
    target = ("127.0.0.1", port)
    fps = max(1, min(60, int(config.get("ai_fps", 15))))
    width, height = int(config.get("ai_width", 320)), int(config.get("ai_height", 240))
    if width <= 0 or height <= 0:
        raise SystemExit("AI resolution must be positive")
    stale_seconds = float(config.get("stale_seconds", 0.35))
    if not 0.1 <= stale_seconds <= 1.0:
        raise SystemExit("stale_seconds must be between 0.1 and 1.0")
    mirror = bool(config.get("mirror", True))
    swap = bool(config.get("swap_hands", False)) ^ args.swap_hands
    min_score = float(config.get("handedness_min_score", 0.65))

    def new_controller():
        return GestureController(float(config.get("stable_seconds", 0.12)),
                                 float(config.get("rearm_seconds", 0.25)))

    controller = new_controller()
    options = mp.tasks.vision.HandLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(model)),
        running_mode=mp.tasks.vision.RunningMode.VIDEO, num_hands=2,
        min_hand_detection_confidence=0.5, min_hand_presence_confidence=0.5,
        min_tracking_confidence=0.5)
    web_bridge = None
    if args.web:
        from gesture_http_bridge import GestureHttpBridge
        try:
            web_bridge = GestureHttpBridge()
        except OSError as exc:
            raise SystemExit(f"Could not start the browser connection on port 8765: {exc}")
        print("Web: open Sensors > Connect camera in the GitHub Pages game.")
    sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send(packet):
        if web_bridge is not None:
            web_bridge.publish(packet)
        sender.sendto(packet, target)
    camera = None
    last_id, timestamp = -1, 0
    last_inference, next_inference, last_send = 0.0, 0.0, 0.0
    display = None
    landmarks = {}
    title = "Unity Hand Control | Q quit | S swap hands | M mirror"
    print("Unity UDP:", target, "| Mirror:", mirror, "| Swap hands:", swap)
    print("Check physical LEFT/RIGHT labels first. S swaps labels; Q exits.")
    try:
        with mp.tasks.vision.HandLandmarker.create_from_options(options) as detector:
            camera = ESP32Camera(url, cv2)
            if not args.no_preview:
                cv2.namedWindow(title, cv2.WINDOW_NORMAL)
                cv2.resizeWindow(title, 960, 720)
            while True:
                now = time.monotonic()
                frame, frame_id, received_at = camera.read()
                new_frame = (frame is not None and frame_id != last_id and
                             now - received_at <= stale_seconds and now >= next_inference)
                if new_frame:
                    last_id = frame_id
                    if mirror:
                        frame = cv2.flip(frame, 1)
                    small = cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)
                    rgb = np.ascontiguousarray(cv2.cvtColor(small, cv2.COLOR_BGR2RGB))
                    timestamp = max(timestamp + 1, int(time.monotonic() * 1000))
                    result = detector.detect_for_video(mp.Image(
                        image_format=mp.ImageFormat.SRGB, data=rgb), timestamp)
                    finished_at = time.monotonic()
                    observations = {"Left": ("NONE", 0.0), "Right": ("NONE", 0.0)}
                    landmarks = {}
                    # Ignore results that took too long, instead of applying stale motion.
                    if finished_at - received_at <= stale_seconds:
                        for hand, categories in zip(result.hand_landmarks, result.handedness):
                            if not categories:
                                continue
                            category = max(categories, key=lambda item: item.score)
                            label = category.category_name
                            if swap and label in observations:
                                label = "Right" if label == "Left" else "Left"
                            if label not in observations or category.score < min_score:
                                continue
                            gesture = classify_hand(hand, width/height,
                                                    float(config.get("ok_touch_ratio", 0.38)))
                            if category.score > observations[label][1]:
                                observations[label] = gesture, category.score
                                landmarks[label.lower() + "Points"] = [
                                    round(max(0, min(1, coord)) * 1000)
                                    for point in hand for coord in (point.x, point.y)
                                ]
                            if not args.no_preview:
                                h, w = frame.shape[:2]
                                points = [(int(lm.x*w), int(lm.y*h)) for lm in hand]
                                for a, b in CONNECTIONS:
                                    cv2.line(frame, points[a], points[b], (0,255,0), 2)
                                for point in points:
                                    cv2.circle(frame, point, 3, (0,0,255), -1)
                                cv2.putText(frame, f"{label}: {gesture} {category.score:.2f}",
                                            points[0], cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,255), 2)
                    controller.update(observations["Left"][0], observations["Right"][0], finished_at)
                    last_inference = received_at
                    next_inference = finished_at + 1/fps
                    if not args.no_preview:
                        display = cv2.resize(frame, (960, 720))
                    send(controller.encode(finished_at - received_at <= stale_seconds, landmarks))
                    last_send = finished_at
                now = time.monotonic()
                camera_live = now - last_inference <= stale_seconds
                if not camera_live:
                    controller.update("NONE", "NONE", now)
                if now - last_send >= 0.1:
                    send(controller.encode(camera_live, landmarks))
                    last_send = now
                if not args.no_preview:
                    screen = display.copy() if display is not None else np.zeros((720,960,3), np.uint8)
                    cv2.rectangle(screen, (0,0), (960,98), (20,20,20), -1)
                    lines = [f"LEFT: {controller.left.gesture}   RIGHT: {controller.right.gesture}",
                             f"Move: {controller.move:+d}  Dash counters L/R: {controller.left.dash_count}/{controller.right.dash_count}",
                             f"Mirror: {mirror}  Swap: {swap}  UDP: 127.0.0.1:{port}"]
                    if now - last_inference > stale_seconds:
                        lines[1] = "NO FRESH HAND DATA - movement released"
                    for i, line in enumerate(lines):
                        cv2.putText(screen, line, (12,25+i*29), cv2.FONT_HERSHEY_SIMPLEX,
                                    0.62, (0,255,255), 1)
                    cv2.imshow(title, screen)
                    key = cv2.waitKey(1) & 0xff
                    if key == ord("q") or cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                        break
                    if key in (ord("s"), ord("m")):
                        if key == ord("s"):
                            swap = not swap
                        else:
                            mirror = not mirror
                        controller = new_controller()
                        landmarks = {}
                        send(controller.encode(camera_live))
                        print("Mirror:", mirror, "Swap hands:", swap,
                              "(temporary; save in config to keep)")
                time.sleep(0.005)
    except KeyboardInterrupt:
        pass
    finally:
        controller.update("NONE", "NONE", time.monotonic())
        try:
            send(controller.encode(False))
        finally:
            sender.close()
            if web_bridge is not None:
                web_bridge.close()
            if camera is not None:
                camera.stop()
            if not args.no_preview:
                cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

