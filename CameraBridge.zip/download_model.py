"""Fetch the official MediaPipe model used by this game."""
from hashlib import sha256
from pathlib import Path
from urllib.request import urlopen

MODEL_URL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
MODEL_SHA256 = "fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1"
model = Path(__file__).with_name("hand_landmarker.task")
if not model.is_file() or sha256(model.read_bytes()).hexdigest() != MODEL_SHA256:
    with urlopen(MODEL_URL, timeout=45) as response:
        data = response.read(10_000_000)
    if sha256(data).hexdigest() != MODEL_SHA256:
        raise SystemExit("The MediaPipe model download failed verification.")
    temporary = model.with_suffix(".tmp")
    temporary.write_bytes(data)
    temporary.replace(model)
print("MediaPipe model ready.")
