# Doki Doki Fruit Catch — Camera helper for Windows

1. Extract the zip. Install Python 3.12 (64-bit), then run install_hand_control.cmd once.
2. Connect the PC and ESP32-CAM to the same Wi-Fi. Stop the video on the camera's browser preview.
3. Run start_camera_web.cmd. Paste the ESP32-CAM stream URL, e.g. http://192.168.4.1:81/stream.
4. Open the game in desktop Chrome or Edge. Click Sensors, then Connect camera. Allow local network access if prompted.
5. Select Camera in the game. Make a fist to move, make an OK sign to dash, or show a V sign to jump. Open the hand between gestures. The game displays the detected hands.
6. If the hand labels are reversed, press S in the helper's preview. Press Q to quit the helper.

The helper processes video on this computer and serves the gesture packet through http://127.0.0.1:8765.
